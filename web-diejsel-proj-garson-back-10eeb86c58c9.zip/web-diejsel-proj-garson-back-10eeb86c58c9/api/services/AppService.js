module.exports = {

  //respond: function(data, options){
  //  return {
  //    success: (options && options.error) ? false : true,
  //    data: (options && options.error) ? options.error : data,
  //  };
  //}

};