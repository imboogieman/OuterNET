module.exports = {

    menu: function (req, res) {
      Category.find({institution_id: req.headers.institution})
        .populate('products')
        .exec(function (err, products) {
          return res.jsonApi(products, {error: err});
        });
    },

    //watch: function (req, res) {
    //    var Id = req.param('id');
    //
    //    Product.findOne(Id)
    //        .exec(function (err, post) {
    //            if (!post) return res.send(404);
    //            if (err) return res.send(500);
    //
    //            res.view({
    //                post: post
    //            });
    //        });
    //},
    //
    //page: function (req, res) {
    //    var page = req.param('page');
    //
    //    Product.find()
    //        .sort('id DESC')
    //        .paginate({
    //            page : page,
    //            limit: 5
    //        })
    //        .exec(function (err, posts) {
    //            if (err) return res.send(500);
    //
    //            res.view({
    //                posts: posts
    //            });
    //        });
    //},
    //
    //create: function (req, res) {
    //    console.log('create');
    //
    //    var params = {
    //        description : req.param('description'),
    //        content     : req.param('content'),
    //        title       : req.param('title'),
    //    };
    //
    //    Product.create(params).exec(function (err, post) {
    //        res.redirect('/post/watch/' + post.id);
    //
    //        if (err) return res.send(500);
    //    });
    //},
    //
    //update: function (req, res) {
    //    var Id = req.param('id');
    //
    //    var elem = {
    //        description : req.param('description'),
    //        content     : req.param('content'),
    //        title       : req.param('title'),
    //    };
    //
    //    Product.update(Id, elem).exec(function (err) {
    //        if (err) return res.send(500);
    //
    //        res.redirect('/');
    //    });
    //},
    //
    //delete: function (req, res) {
    //    var Id = req.param('id');
    //
    //    Product.destroy(Id).exec(function (err) {
    //        if (err) return res.send(500);
    //        res.redirect('/post');
    //    });
    //}

};

