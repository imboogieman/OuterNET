module.exports = {

    add: function (req, res) {
      return res.jsonApi(); //params -> ({}, {error: false})
    },

};

