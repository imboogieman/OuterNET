GARSON.PRO - Back App 
========================

Development
------------

Command (one of) for start development, where app start on http://localhost:1337:
```bash
# sails lift
# node app.js --dev
```

Production
------------

Command for start prodaction, where app start on port 1337:
```bash
# forever start app.js --prod
```