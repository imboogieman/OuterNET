module.exports = function(config) {
  config.set({

    basePath: './',

    frameworks: ['jasmine'],

    files: [
      //system
      //{pattern: 'build/frontend/assets/js/script.js', included: true, watched: true},
      {pattern: 'build/system/common.js', included: true, watched: true},
      //test
      {pattern: 'node_modules/angular2/bundles/testing.dev.js', included: true, watched: true},
      {pattern: 'karma-test-shim.js', included: true, watched: true},
      //project
      {pattern: 'build/**/*.js', included: false, watched: true},
      {pattern: 'build/**/*_spec.js', included: false, watched: true},
    ],

    //// proxied base paths
    //proxies: {
    //  // required for component assests fetched by Angular's compiler
    //  "/build/": "/base/build/"
    //},

    port: 9876,

    logLevel: config.LOG_INFO,

    colors: true,

    autoWatch: true,

    browsers: ['Chrome'],

    // Karma plugins loaded
    plugins: [
      'karma-jasmine',
      'karma-coverage',
      'karma-chrome-launcher',
    ],

    //// Coverage reporter generates the coverage
    //reporters: ['progress', 'dots', 'coverage'],
    //
    //// Source files that you wanna generate coverage for.
    //// Do not include tests or libraries (these files will be instrumented by Istanbul)
    //preprocessors: {
    //  'build/**/!(*spec).js': ['coverage']
    //},
    //
    //coverageReporter: {
    //  reporters:[
    //    {type: 'json', subdir: '.', file: 'coverage-final.json'}
    //  ]
    //},
    //
    //singleRun: true,
    //
    //exclude: [
    //  'build/**/*.spec.js'
    //]

  })
};