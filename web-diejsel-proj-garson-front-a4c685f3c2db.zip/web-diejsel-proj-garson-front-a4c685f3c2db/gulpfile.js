var gulp = require('gulp'),
    rename = require('gulp-rename'),
    traceur = require('gulp-traceur'),
    webserver = require('gulp-webserver'),
    $ = require('gulp-load-plugins')(),
    es = require('event-stream'),
    extend = require('gulp-extend');
    //yargs = require('yargs').argv; //flags

var apps = ['frontend', 'backend'];
var flags = {
  env: {
    isProd: process.argv.indexOf('prod') > -1,
    name: (process.argv.indexOf('prod') > -1) ? 'prod' : 'dev',
  },
};

// run init tasks
var taskDefault = ['dependencies', 'tr-js', 'html', 'api'];
apps.map(function(app){
  taskDefault.push(app + '-js');
  taskDefault.push(app + '-css');
  taskDefault.push(app + '-files');
  taskDefault.push(app + '-config');
});
gulp.task('default', taskDefault);

// run development task
gulp.task('dev', ['default', 'serve']);

// run production task
gulp.task('prod', ['default']);

// serve the build dir
gulp.task('serve', ['default', 'watch'], function () {
  gulp.src('build')
    .pipe(webserver({
      livereload: true,
      open: true,
    }));
});

// watch for changes and run the relevant task
gulp.task('watch', function () {
  gulp.watch([
    'src/**/*.js',
    '!src/**/assets/**/*.js'
  ], ['tr-js']);
  apps.map(function(app){
    gulp.watch([
      'src/common/assets/js/libs/*.js',
      'src/common/assets/js/*.js',
      'src/' + app + '/assets/js/libs/*.js',
      'src/' + app + '/assets/js/*.js'
    ], [app + '-js']);
    gulp.watch([
      'src/common/assets/css/libs/*.css',
      'src/common/assets/css/*.css',
      'src/common/assets/**/*.less',
      'src/' + app + '/assets/css/libs/*.css',
      'src/' + app + '/assets/css/*.css',
      'src/' + app + '/assets/**/*.less'
    ], [app + '-css']);
    gulp.watch([
      'src/' + app + '/assets/img/**/*',
      'src/' + app + '/assets/doc/**/*',
      'src/' + app + '/assets/fonts/**/*'
    ], [app + '-files']);
    gulp.watch([
      'src/common/config.json',
      'src/common/config_' + flags.env.name + '.json',
      'src/' + app + '/config.json'
    ], [app + '-config']);
  });
  gulp.watch('src/**/*.html', ['html']);
  gulp.watch('src/**/*.json', ['api']);
});

// move dependencies into build dir
gulp.task('dependencies', function () {
  return gulp.src([
    //system
    'node_modules/es6-shim/es6-shim.min.js',
    'node_modules/angular2/bundles/angular2-polyfills.js',
    'node_modules/traceur/bin/traceur-runtime.js',
    'node_modules/systemjs/dist/system.js',
    'node_modules/systemjs/dist/system-csp-production.src.js',
    'node_modules/reflect-metadata/Reflect.js',
    'system/code/system.config.js',
    'node_modules/angular2/bundles/angular2.js',
    'node_modules/rxjs/bundles/Rx.js',
    'system/code/system.import.js',

    //project modules
    'node_modules/angular2/bundles/router.js',
    'node_modules/angular2/bundles/http.js',
  ])
    .pipe($.concat('common.js'))
    //.pipe($.uglify()) //min
    .pipe(gulp.dest('build/system'));
});

// transpile & move js
gulp.task('tr-js', function () {
  return gulp.src([
    'src/**/*.js',
    //'!src/**/*_spec.js', //todo: test
    '!src/**/assets/**/*.js'
  ])
    .pipe(rename({
      extname: ''
    }))
    .pipe(traceur({
      modules: 'instantiate',
      moduleName: true,
      annotations: true,
      types: true,
      memberVariables: true
    }))
    .pipe(rename({
      extname: '.js'
    }))
    .pipe(gulp.dest('build'));
});

// move js && css
apps.map(function(app){
  // move js
  gulp.task(app + '-js', function () {
    return gulp.src([
        'src/common/assets/js/libs/*.js',
        'src/common/assets/js/*.js',
        'src/' + app + '/assets/js/libs/*.js',
        'src/' + app + '/assets/js/*.js'
      ])
      .pipe($.concat('script.js'))
      .pipe($.uglify()) //min
      .pipe(gulp.dest('build/' + app + '/assets/js'));
  });

  // move css
  gulp.task(app + '-css', function () {
    return gulp.src([
        'src/common/assets/css/libs/*.css',
        'src/common/assets/css/*.css',
        'src/common/assets/**/*.less',
        'src/' + app + '/assets/css/libs/*.css',
        'src/' + app + '/assets/css/*.css',
        'src/' + app + '/assets/**/*.less'
      ])
      .pipe($.concat('style.css'))
      .pipe($.less())
      .pipe($.csso()) //min
      .pipe(gulp.dest('build/' + app + '/assets/css'));
  });

  // move files
  gulp.task(app + '-files', function () {
    return es.merge(
      gulp.src('src/' + app + '/assets/img/**/*').pipe(gulp.dest('build/' + app + '/assets/img/')),
      gulp.src('src/' + app + '/assets/doc/**/*').pipe(gulp.dest('build/' + app + '/assets/doc/')),
      gulp.src('src/' + app + '/assets/fonts/**/*').pipe(gulp.dest('build/' + app + '/assets/fonts/'))
    );
  });

  //move config
  gulp.task(app + '-config', function () {
    return gulp.src([
        'src/common/config.json',
        'src/common/config_' + flags.env.name + '.json',
        'src/' + app + '/config.json'
      ])
      .pipe(extend('config.json'))
      .pipe(gulp.dest('build/' + app));
  });
});

// move html
gulp.task('html', function () {
  return gulp.src('src/**/*.html')
    .pipe(gulp.dest('build'))
});

// move api
gulp.task('api', function () {
  return gulp.src([
    'src/**/*.json',
    '!src/**/config.json'
  ])
    .pipe(gulp.dest('build'))
});
