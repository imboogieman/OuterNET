GARSON.PRO - Front App 
========================

Development
------------

Command for start development, where app start on http://localhost:8000:
```bash
# gulp dev
```

Production
------------

Command for start prodaction, where app in folder [build]:
```bash
# gulp prod
```


