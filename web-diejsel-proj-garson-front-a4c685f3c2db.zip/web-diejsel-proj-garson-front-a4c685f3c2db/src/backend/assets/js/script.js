$(document).ready(function(){

  //jquery custom
  //$.fn.extend({
  //  //animate
  //  animateCss: function (animationName, isRemoveClass) {
  //    var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
  //    $(this).addClass('animated ' + animationName).one(animationEnd, function() {
  //      if (isRemoveClass){ $(this).removeClass('animated ' + animationName); }
  //    });
  //  },
  //});
  //$.extend({
  //  //scroll
  //  scrollDown: function (){
  //    $('html, body').animate({ scrollTop: $(document).height() }, 1000);
  //  },
  //});

});