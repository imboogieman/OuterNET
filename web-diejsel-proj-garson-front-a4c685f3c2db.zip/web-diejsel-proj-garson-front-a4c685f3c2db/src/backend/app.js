import {Component, provide} from 'angular2/core';
import {RouteConfig, Router, ROUTER_PROVIDERS, ROUTER_DIRECTIVES} from 'angular2/router';
import {Location, LocationStrategy, HashLocationStrategy} from 'angular2/platform/common'; //hash tag
import {HTTP_PROVIDERS} from 'angular2/http';
import {enableProdMode} from 'angular2/core';
import {bootstrap} from 'angular2/platform/browser';
import {Title} from 'angular2/platform/browser';
import {Front} from 'common/components/widgets/front';
import {Home} from 'backend/controllers/home';
import {About} from 'backend/controllers/about';
import {COMMON_DIRECTIVES} from 'angular2/common';

@Component({
  selector: 'main',
  directives: [Front, ROUTER_DIRECTIVES, COMMON_DIRECTIVES],
  providers: [Title],
  templateUrl: 'backend/layouts.html',
})
@RouteConfig([
  {path: '/', component: Home, name: 'Home', useAsDefault: true},
  {path: '/about', component: About, name: 'About'}
])
class App {

  layout = 'default';

  constructor(
      router:Router,
      title:Title
  ){
    router.subscribe((url)=>{ //fires on every URL change
      title.setTitle(url);
    });
  }

}

//enableProdMode();
bootstrap(App, [
  ROUTER_PROVIDERS,
  HTTP_PROVIDERS,
  provide(LocationStrategy, {useClass: HashLocationStrategy}), //hash tag
]);