import {Component} from 'angular2/core';

@Component({
  templateUrl: 'frontend/views/home.html'
})
export class Home {}