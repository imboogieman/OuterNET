import {Component} from 'angular2/core';

@Component({
  templateUrl: 'frontend/views/about.html'
})
export class About {}