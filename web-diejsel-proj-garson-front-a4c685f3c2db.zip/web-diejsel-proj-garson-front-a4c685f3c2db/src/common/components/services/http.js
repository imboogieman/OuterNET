import 'rxjs/add/operator/map';
import {Component} from 'angular2/core';
import {Http, Headers, RequestOptions} from 'angular2/http';
import {AppService} from 'common/components/services/app';

@Component({
  providers: [AppService]
})
export class HttpService {

  headers = {
    'Content-Type': 'Accepts,X-Requested-With',
    'Accept': 'application/json'
  };
  header = null;
  option = null;

  constructor(
    app:AppService,
    http:Http
  ) {
    this.app = app;
    this.http = http;
  }

  initConfig() {
    //upload config file and merge with AppService
    let $this = this;
    this.get({url: '/' + this.app.name + '/config.json', notUseApi: true}, function(data){
      for(let item in data) {
        $this.app[item] = data[item];
      }

      //event - after config
      $this.app.onAfterInitConfig();
    });
  }

  initHeaders (){
    //union headers
    $.extend(this.headers, this.app.headers);

    this.header = new Headers(this.headers);
    this.option = new RequestOptions({ headers: this.header });
  }

  getUrl(url) {
    //without api
    if (typeof url === 'object' && url){
      if (url.notUseApi){
        return url.url;
      }

      url = url.url;
    }

    //with api
    if (!url){
      return '';
    }else{
      return (this.app.debug.level.request ? '/api' : this.app.api) + url + (this.app.debug.level.request ? '.json' : '');
    }
  }

  getInit(url, callback) {
    this.initHeaders();
    let http = this.http
      .get(
        this.getUrl(url),
        this.option
      )
      .map(res => res.json());

    if (callback) {
      http
        .subscribe(
          data => {
            callback(data);
          },
          err => console.warn(err)
          //() => console.log('Random Quote Complete')
        );
    }

    return http;
  }

  postInit(url, body, callback) {
    this.initHeaders();
    let http = this.http
      .post(
        this.getUrl(url),
        JSON.stringify(body),
        this.option
      )
      .map(res => res.json());

    if (callback) {
      http
        .subscribe(
          data => {
            callback(data);
          },
          err => console.warn(err)
          //() => console.log('Random Quote Complete')
        );
    }

    return http;
  }

  get(url, callback) {
    if (typeof url === 'object' && url.event){
      url.event.subscribe((data) => {
        this.getInit(url, callback);
      });
    }else{
      return this.getInit(url, callback);
    }
  }

  post(url, body, callback) {
    if (typeof url === 'object' && url.event){
      url.event.subscribe((data) => {
        this.postInit(url, body, callback);
      });
    }else{
      return this.postInit(url, body, callback);
    }
  }

  delete(url, body, callback) {
    //todo: ...
  }

}