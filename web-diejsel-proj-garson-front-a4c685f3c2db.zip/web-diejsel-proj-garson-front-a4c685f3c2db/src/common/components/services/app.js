import {EventEmitter} from 'angular2/core'

export class AppService {

  name = 'common';
  api = 'http://localhost:8000';
  debug = false;                    //load local api
  layout = 'default';
  auth = {
    token: '',
    isAuth: true,
    info: {}
  };
  page = {
    titles: {}
  };
  headers = {};
  scope = {};                      //clear change state
  data = {};                       //not clear change state

  //Events
  eventAppLoadData = new EventEmitter();
  onAfterInitConfig (){}

}