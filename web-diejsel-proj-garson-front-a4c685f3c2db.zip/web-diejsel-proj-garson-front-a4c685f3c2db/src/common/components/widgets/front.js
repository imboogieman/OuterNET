import {Component} from 'angular2/core';
import {NgFor} from 'angular2/common';
import {HttpService} from 'common/components/services/http';
//import {AlertComponent} from 'ng2-bootstrap/ng2-bootstrap';

@Component({
  selector: 'front',
  providers: [HttpService],
  directives: [NgFor /*, AlertComponent*/],
  templateUrl: 'common/components/views/widget-front.html'
})
export class Front {

  list = ['first', 'second', 'tree'];
  valueFront = '123';
  dataInit = {name: ''};

  constructor(http:HttpService) {
    this.http = http;
    this.valueFront = '456';

    setTimeout(function(){
      console.log($('#inputFront').val());
    });
  }

  addName(newname) {
    this.list.push(newname);
    this.valueFront = '';
  }

  sendName(newname) {
    this.http.get('/api/core/init.json', function(data){
      console.log(data);
    });

    this.http.post('/api/core/init.json', {param: 'ok'}, function(data){
      console.log(data);
    });
  }

  onChange(event) {
    console.log(event.target.value);
  }

}
