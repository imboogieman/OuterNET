import {Pipe} from 'angular2/core';

@Pipe({
  name: 'objLength',
  pure: false //change for object
})
export class ObjLengthFilter {
  transform(items, args){
    return Object.keys(items).length;
  }
}