import {Pipe} from 'angular2/core';

@Pipe({
  name: 'objArray',
  pure: false //change for object
})
export class ObjArrayFilter {
  transform(value, args){
    let keys = [];
    for (let key in value) {
      keys.push(value[key]);
    }
    return keys;
  }
}