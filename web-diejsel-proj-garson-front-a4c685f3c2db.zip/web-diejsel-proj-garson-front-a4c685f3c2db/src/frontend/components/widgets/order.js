import {Component} from 'angular2/core';
import {RouterLink} from 'angular2/router';
import {HttpService} from 'common/components/services/http';
import {OrderService} from 'frontend/components/services/order';
import {ObjLengthFilter} from 'common/components/filters/objLength';
import {NgIf} from 'angular2/common';

@Component({
  selector: 'widget-order',
  //providers: [HttpService, OrderService],
  directives: [RouterLink, NgIf],
  pipes: [ObjLengthFilter],
  templateUrl: 'frontend/components/views/widget-order.html'
})
export class OrderWidget {

  totalPrice = 0;

  constructor(
    http:HttpService,
    order:OrderService
  ) {
    this.http = http;
    this.order = order;
  }

  onOrder (){
    //send post data
    if (location.hash === '#/order'){
      let $this = this;
      this.http.post('/order/add', {list: this.order.list}, function(res){
        if (res.success){
          $this.order.isOrderSend = true;
          $this.order.list = {};
          $this.order.eventChangeList.emit();
        }
      });
    }
  }

}