import {Component} from 'angular2/core';
import {OrderService} from 'frontend/components/services/order';
import {NgIf, NgClass} from 'angular2/common';

@Component({
  selector: 'widget-order-btn',
  inputs: ['product'],
  directives: [NgIf, NgClass],
  templateUrl: 'frontend/components/views/widget-order-btn.html'
})
export class OrderBtnWidget {

  product = null;

  constructor(
    order:OrderService
  ) {
    this.order = order;
  }

}