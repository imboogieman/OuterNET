import {Component, EventEmitter} from 'angular2/core'

export class OrderService {

  list = {
    //example
    // 1: {count: 5, price: 250, error: true},
    // 2: {count: 1, price: 50},
    // 3: {count: 3, price: 20}
  };

  total = {
    price: 0,
    count: 0
  };

  isOrderSend = false;

  //events
  eventChangeList = new EventEmitter();
  eventInitPressPrice = new EventEmitter();

  constructor (){
    //events
    this.eventChangeList.subscribe(() => {
      this.getTotal();
    });
    this.eventInitPressPrice.subscribe(() => {
      this.initPressPrice();
    });

    //emit
    this.eventChangeList.emit();
  }

  addPosition (product, option){
    let $this = this;
    let funAddDuration = function(){
      let funAdd = function(){
        $this.list[product.id].count += 1;

        //emit
        $this.eventChangeList.emit();
      };
      if (option && option.duration){ //duration for add
        setTimeout(funAdd, 400);
      }else{
        funAdd();
      }
    };

    if (this.list[product.id] === undefined){
      this.list[product.id] = $.extend({count: 0}, product);
      funAddDuration();
    }else{
      if (this.list[product.id].count < 20){
        funAddDuration();
      }else{
        this.list[product.id].error = true;
      }
    }
  }

  delPosition (product){
    if (this.list[product.id] !== undefined){
      if (this.list[product.id].count === 1){
        delete this.list[product.id];
      }else{
        this.list[product.id].count -= 1;
        this.list[product.id].error = false;
      }

      //emit
      this.eventChangeList.emit();
    }
  }

  removePosition (product){
    if (this.list[product.id] !== undefined){
      delete this.list[product.id];

      //emit
      this.eventChangeList.emit();
    }
  }

  getTotal (){
    let totalPrice = 0;
    let totalCount = 0;
    for (let id in this.list){
      totalPrice += this.list[id].price * this.list[id].count;
      totalCount += this.list[id].count;
    }

    this.total.price = totalPrice;
    this.total.count = totalCount;
  }

  initPressPrice (){ //show panel
    setTimeout(function(){
      $('.j-price').on('click', function(){
        var $price = $(this);
        var $order = $price.siblings('.j-order');

        setTimer($order, $price);
      });

      $('.j-order-btn').on('click', function(){
        var $order = $(this).parent();
        var $price = $order.siblings('.j-price');

        setTimer($order, $price);
      });

      function setTimer($order, $price){
        var timer = $order.data('timer');
        if (timer){
          clearTimeout(timer);
        }

        $price.hide();
        $order.show();

        $order.data('timer', setTimeout(function(){
          $price.show();
          $order.hide();
        }, 1000));
      }
    });
  }

}