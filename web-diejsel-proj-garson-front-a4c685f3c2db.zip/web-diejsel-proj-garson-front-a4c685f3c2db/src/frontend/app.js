//system
import {Component, provide} from 'angular2/core';
import {enableProdMode} from 'angular2/core';
import {bootstrap} from 'angular2/platform/browser';
import {RouteConfig, Router, AsyncRoute, ROUTER_PROVIDERS, ROUTER_DIRECTIVES} from 'angular2/router';
import {Location, LocationStrategy, HashLocationStrategy} from 'angular2/platform/common'; //hash tag
import {HTTP_PROVIDERS} from 'angular2/http';
import {Title} from 'angular2/platform/browser';
import {COMMON_DIRECTIVES} from 'angular2/common';
//services
import {AppService} from 'common/components/services/app';
import {HttpService} from 'common/components/services/http';
import {HelperService} from 'common/components/services/helper';
import {OrderService} from 'frontend/components/services/order';
//widgets
import {OrderWidget} from 'frontend/components/widgets/order';
//controllers
//import {Home} from 'frontend/controllers/home';
//import {About} from 'frontend/controllers/about';
import {Products} from 'frontend/controllers/products';
import {Order} from 'frontend/controllers/order';

@Component({
  selector: 'main',
  directives: [ROUTER_DIRECTIVES, COMMON_DIRECTIVES, OrderWidget],
  providers: [Title, AppService, HttpService, OrderService, HelperService],
  templateUrl: 'frontend/layouts.html',
})
@RouteConfig([
  {path : '/', redirectTo: ['Products']},
  //{path: '/', component: Home, name: 'Home'},
  //{path: '/about', component: About, name: 'About'},
  {path: '/menu', component: Products, name: 'Products', useAsDefault: true},
  new AsyncRoute({
    path: '/menu/:id',
    name: 'Product',
    loader: () => HelperService.loadAsync('Product', 'frontend/controllers/product')
  }),
  //new AsyncRoute({
  //  path: '/order',
  //  name: 'Order',
  //  loader: () => HelperService.loadAsync('Order', 'frontend/controllers/order')
  //}),
  {path: '/order', component: Order, name: 'Order'}, //todo: lazyload (not work pipes)
])
class App {

  constructor(
      router:Router,
      //location:Location,
      title:Title,
      app:AppService,
      http:HttpService
      //helper:HelperService
  ) {
    let $this = this;
    this.app = app;
    this.http = http;

    //init app
    this.app.name = 'frontend';
    this.app.onAfterInitConfig = function(){
      //upload data of institution (by subdomain)
      let pos = location.host.indexOf('.');
      let slug = location.host.substr(0, pos);
      //if env dev (get institution name from dev config)
      if ($this.app.env.isDev &&
          location.hostname === 'localhost'
      ){ slug = $this.app.env.data.institutionSlug; }
      //http
      $this.http.get('/institution/' + slug + '/init', function(res){
        if (res.success){
          $this.app.data.institution = res.data;
          $this.app.headers['Institution'] = $this.app.data.institution.id;
          $this.app.eventAppLoadData.emit(res.data);
          $this.app.eventAppLoadData = null; //emit once
        }
      });
    };
    this.http.initConfig();

    //change route
    router.subscribe((url)=>{
      //reset
      this.app.scope = {};

      //set title
      for (let titleItem in this.app.page.titles) {
        var regTitle = new RegExp(titleItem);
        if (regTitle.test(url)) {
          title.setTitle(this.app.page.titles[titleItem]);
          continue;
        }
      }
    });

    //todo: save params url (first)
    //var url = location.path();
    //var pos = url.indexOf('?');
    //if (pos > -1){
    //  var params = helper.URLToArray(url);
    //  this.app.data.url = params;
    //}

    //theme
    this.initTheme();
  }

  initTheme() {
    setTimeout(function(){
      $(document).ready(MAJESTY.documentOnReady.init);
      $(window).load(MAJESTY.documentOnLoad.init);
      $(window).on('resize', MAJESTY.documentOnResize.init);
      MAJESTY.documentOnResize.init();
    });
  }

}

//enableProdMode(); //todo: prod mode
bootstrap(App, [
  ROUTER_PROVIDERS,
  HTTP_PROVIDERS,
  provide(LocationStrategy, {useClass: HashLocationStrategy}), //hash tag
  OrderService
]);