import {it, describe, expect, beforeEach} from 'angular2/testing';
import {AppService} from 'common/components/services/app';

describe('AppService tests', () => {

  let app:AppService;
  let list:Array;

  beforeEach(() => {
    app = new AppService();
  });

  it('Should get 5 dogs', () => {
    expect(app.name).toBe('common');

    list = ['golden retriever', 'french bulldog'];
    expect(list.length).toBe(2);
    expect(list).toEqual(['golden retriever', 'french bulldog']);
  });

});