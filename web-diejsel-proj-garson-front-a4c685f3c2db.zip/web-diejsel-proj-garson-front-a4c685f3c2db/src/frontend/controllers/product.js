import {Component} from 'angular2/core';
import {RouteParams} from 'angular2/router';
import {AppService} from 'common/components/services/app';

@Component({
  templateUrl: 'frontend/views/product.html'
})
export class Product {

  id:string;

  constructor(
      app:AppService,
      params:RouteParams
  ){
    //theme
    setTimeout(function(){
      MAJESTY.widget.carouselImage();
    });

    this.id = params.get('id');
  }

}