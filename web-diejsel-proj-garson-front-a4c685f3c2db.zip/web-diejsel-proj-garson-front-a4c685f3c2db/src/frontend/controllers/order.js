import {Component} from 'angular2/core';
import {RouterLink} from 'angular2/router';
import {AppService} from 'common/components/services/app';
import {HttpService} from 'common/components/services/http';
import {OrderService} from 'frontend/components/services/order';
import {OrderBtnWidget} from 'frontend/components/widgets/order-btn';
import {ObjArrayFilter} from 'common/components/filters/objArray';
import {ObjLengthFilter} from 'common/components/filters/objLength';
import {NgFor, NgIf, NgClass} from 'angular2/common';

@Component({
  providers: [HttpService],
  directives: [RouterLink, NgFor, NgIf, NgClass, OrderBtnWidget],
  pipes: [ObjArrayFilter, ObjLengthFilter],
  templateUrl: 'frontend/views/order.html'
})
export class Order {

  constructor (
    app:AppService,
    http:HttpService,
    order:OrderService
  ){
    var $this = this;
    this.app = app;
    this.http = http;
    this.order = order;

    //emit
    this.order.eventInitPressPrice.emit();
  }

}