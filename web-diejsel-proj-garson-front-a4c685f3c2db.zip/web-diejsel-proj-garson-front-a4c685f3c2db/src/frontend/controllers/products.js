import {Component} from 'angular2/core';
import {RouterLink, RouteParams} from 'angular2/router';
import {AppService} from 'common/components/services/app';
import {HttpService} from 'common/components/services/http';
import {OrderService} from 'frontend/components/services/order';
import {OrderBtnWidget} from 'frontend/components/widgets/order-btn';
import {NgFor, NgIf, NgClass} from 'angular2/common';

@Component({
  providers: [HttpService],
  directives: [RouterLink, NgFor, NgIf, NgClass, OrderBtnWidget],
  templateUrl: 'frontend/views/products.html'
})
export class Products {

  menu = [
    {
      "id": 0,
      "title": "All",
      "products": []
    }
  ];
  curCategory = 0;

  constructor (
    app:AppService,
    http:HttpService,
    order:OrderService,
    params:RouteParams
  ){
    var $this = this;
    this.app = app;
    this.http = http;
    this.order = order;

    //get menu
    this.http.get({url: '/product/menu/', event: this.app.eventAppLoadData}, function(res){
      $this.menu = $this.menu.concat(res.data);

      //emit
      $this.order.eventInitPressPrice.emit();
    });
  }

  setCurCategory (index){
    this.curCategory = index;

    //emit
    this.order.eventInitPressPrice.emit();
  }

}