System.config({
  defaultJSExtensions: true,
});